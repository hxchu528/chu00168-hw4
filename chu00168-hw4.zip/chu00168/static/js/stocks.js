async function displayStock(){
    var symbol = document.getElementById("stock").value;
    var textArea = document.getElementById("stockInfo");
    var url = "https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol="+symbol+"&interval=5min&apikey=H0OLHRTG4SUK32A7"
    const response = await fetch(url);
    var data = await response.json();
    console.log(data)
    textArea.value = JSON.stringify(data);
}
document.getElementById("getStock").addEventListener("click",displayStock);