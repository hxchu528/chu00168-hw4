(g=>{var h,a,k,p="The Google Maps JavaScript API",c="google",l="importLibrary",q="__ib__",m=document,b=window;b=b[c]||(b[c]={});var d=b.maps||(b.maps={}),r=new Set,e=new URLSearchParams,u=()=>h||(h=new Promise(async(f,n)=>{await (a=m.createElement("script"));e.set("libraries",[...r]+"");for(k in g)e.set(k.replace(/[A-Z]/g,t=>"_"+t[0].toLowerCase()),g[k]);e.set("callback",c+".maps."+q);a.src=`https://maps.${c}apis.com/maps/api/js?`+e;d[q]=f;a.onerror=()=>h=n(Error(p+" could not load."));a.nonce=m.querySelector("script[nonce]")?.nonce||"";m.head.append(a)}));d[l]?console.warn(p+" only loads once. Ignoring:",g):d[l]=(f,...n)=>r.add(f)&&u().then(()=>d[l](f,...n))})({
    key: "AIzaSyBMfRBft4HqR03I8d855vKViczegroYdN4",//"AIzaSyAIi5_mMG8fClTY4gZECKrxkjVU_jbNuRo",
    v: "weekly",
    // Use the 'v' parameter to indicate the version to use (weekly, beta, alpha, etc.).
    // Add other bootstrap parameters as needed, using camel case.
});
var map;
var geocoder;
var crd = [0,0];
function get(pos){
    crd = [pos.coords.latitude,pos.coords.longitude];
}
navigator.geolocation.getCurrentPosition(get)
async function direction(){
    var directionsService = new google.maps.DirectionsService();
    var directionsRenderer = new google.maps.DirectionsRenderer({map: map});
    
    var dest = document.getElementsByName("goto")[0];
    var select = document.getElementsByName("travel");
    var mode;
    select.forEach(i =>{if(i.checked){mode = i.value;}});
    if(mode === "WALK"){mode = "WALKING";}//google.maps.TravelMode.WALKING}
    if(mode === "DRIVE"){mode = "DRIVING";}//google.maps.TravelMode.DRIVING}
    if(mode === "TRANSIT"){mode = "TRANSIT";}//google.maps.TravelMode.TRANSIT}
    async function geocodeLocation(location1){
        return new Promise((resolve, reject) => {
            geocoder.geocode({address: location1}, function(results, status) {
                if (status === 'OK'){
                    resolve(results[0].geometry.location)
                }
            })
        })
    }
    dest = await geocodeLocation(dest.value);
    var option = {
        origin:{lat: crd[0], lng: crd[1]},
        destination: dest,
        travelMode: mode
    }
    directionsService.route(option).then((response)=>{
        directionsRenderer.setDirections(response);
    })
    .catch((e) => window.alert("Directions request failed due to " + status));
}
document.getElementById("travel").addEventListener("click",direction);
document.addEventListener("DOMContentLoaded",
async function googleMap(){
    //
    var locations = [];
    var tr = document.querySelector("#schedule tbody").children;
    for(let i = 1; i<tr.length; i++){
        var td = tr[i].children;
        locations.push({
            loc: td[3].innerHTML.substring(0,td[3].innerHTML.indexOf("<img")),
            content: `<b>${td[1].innerHTML}</b><br>${td[0].innerHTML}, ${td[2].innerHTML}`
        });
    }
    //
    const {Map} = await google.maps.importLibrary("maps")//await googleMap.mapsimportLibrary("maps");
    map = new Map(document.getElementById("googleMap"), {
        center: { lat: 44.9727, lng: -93.23540000000003 },
        zoom: 14,
        mapId:"maps"
    });
    geocoder = new google.maps.Geocoder();
    const {AdvancedMarkerElement} = await google.maps.importLibrary("marker");
    async function geocodeLocation(location1){
        return new Promise((resolve, reject) => {
            geocoder.geocode({address: location1}, function(results, status) {
                if (status === 'OK'){
                    resolve(results[0].geometry.location)
                }
            })
        })
    }
    for(let i = 0; i<locations.length; i++){
        const position = await geocodeLocation(locations[i].loc);
        const gopherImg = document.createElement("img");
        gopherImg.src = '../img/Goldy.png';
        gopherImg.width = 20;
        gopherImg.height = 20;
        const marker = new AdvancedMarkerElement({map: map, position: position, content:gopherImg})
        const infoWindow = new google.maps.InfoWindow({
            content:locations[i].content,
        });
        marker.addEventListener("gmp-click",function(){
            infoWindow.open(map,marker);
        })
        let pos = locations[i].content.indexOf("</b>")
        const infoWindow2 = new google.maps.InfoWindow({
            content:locations[i].content.substring(0,pos+4)
        });
        marker.addEventListener("mouseover",function(){
            infoWindow2.open(map,marker);
        })
        marker.addEventListener("mouseout",function(){
            infoWindow2.close();
        })
    }
});