const time = document.getElementById("time");
const timeSeg = time.children;
function updateTime(){
    requestAnimationFrame(updateTime);
    let date = new Date();
    let hour = date.getHours();
    let min = date.getMinutes().toString();
    let sec = date.getSeconds().toString();
    if(min.length<2){
        min = "0"+min;
    }
    if(sec.length<2){
        sec = "0"+sec;
    }
    timeSeg[4].innerHTML = hour===0?12: hour>12?hour-12: hour;
    timeSeg[5].innerHTML = min;
    timeSeg[6].innerHTML = sec;
    timeSeg[7].innerHTML = hour>=13?"PM":"AM";
}
updateTime();