var tr = document.querySelector("#schedule tbody").children;
var bigPicImg = document.getElementById("bigPicture");
var srcList = ['../img/img1.png','../img/img2.jpg','../img/img3.png','../img/img4.png','../img/img5.png','../img/img6.png','../img/img7.png','../img/gophers-mascot.png']
var srcInd = srcList.length-1;
var interval;
function showBigPicImg(num){
    var img = bigPicImg.children[0];//document.getElementsByTagName("img")[0];
    img.src = `../img/img${num+1}.${num===1?"jpg":"png"}`
    img.alt = "placeholder";
}
function fadeIn(){
    var img = bigPicImg.children[0];
    srcInd+=1;
    if(srcInd>=srcList.length){srcInd = 0;}
    img.src = srcList[srcInd];
    img.style.opacity = 1;
    img.style.transition = "opacity 0.5s ease-in-out";
}
function fadeOut(){
    var img = bigPicImg.children[0];
    img.style.opacity = 0;
    img.style.transition = "opacity 0.5s ease-in-out";
}
function changeImg(){
    fadeOut();
    setTimeout(fadeIn,500);
}
function slideshow(){
    changeImg();
    interval = setInterval(changeImg,4000)
}
function stopSlideshow(){
    clearInterval(interval);
}
document.getElementById("start").addEventListener("click",slideshow);
document.getElementById("stop").addEventListener("click",stopSlideshow);
for(let i = 0; i<tr.length; i++){
    tr[i].addEventListener("mouseenter",function(){
        if(i===1 || i===5 || i===12){
            showBigPicImg(0);
        }
        else if(i===2 || i===6 || i===9 || i===14){
            showBigPicImg(3);
        }
        else if(i===3 || i===7 || i===10 || i===15){
            showBigPicImg(4);
        }
        else if(i===4 || i===11 || i===13){
            showBigPicImg(1);
        }
        else if(i===8){
            showBigPicImg(2);
        }
        else if(i===16){
            showBigPicImg(5)
        }else if(i===17){
            showBigPicImg(6)
        }
    })
}